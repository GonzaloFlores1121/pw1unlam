



var combo=document.getElementById('combo');
 
function cambiarColor(idParrafo, combo) {
    var parrafo = document.getElementById(idParrafo);

    // Obtén el valor seleccionado
    var valorSeleccionado = combo.value;

    // Asigna la clase correspondiente al párrafo
    switch (valorSeleccionado) {
        case 'pink':
            parrafo.className = 'pink';
            break;
        case 'yellow':
            parrafo.className = 'yellow';
            break;
        case 'green':
            parrafo.className = 'green';
            break;
        default:
            parrafo.className = ''; // Restablecer a la clase por defecto
    }
}
document.querySelectorAll('input[type="radio"]').forEach(function(radio) {
    radio.addEventListener('click', function() {
        var contenedor = document.querySelector('.contenedor');
        contenedor.style.flexWrap = (this.value === '2') ? 'wrap' : 'nowrap';
    });
});

function calcularSumaNotas() {
    // Aquí debes implementar la lógica para calcular la suma de todas las notas
    // Puedes obtener el valor de cada combo y sumarlos
    // Por ejemplo:
    var suma = 0;
    var combos = document.querySelectorAll('.combo select');
    combos.forEach(function (combo) {
        suma += parseFloat(combo.value) || 0;
    });
    return suma;
}

    // Crea y agrega nuevas opciones al combo
   



    