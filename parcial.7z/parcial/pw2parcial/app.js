var input = document.getElementById('texto');
var output= document.getElementById('titulo');

input.addEventListener('input',function(){
output.innerText=input.value;
}
);
document.getElementById('color').addEventListener('change',
function(){
    var select = document.getElementById("color");
            var articleUni = document.getElementById('primer');
            articleUni.style.backgroundColor = select.value;
});

var radioButtons = document.querySelectorAll('input[type="radio"]');
radioButtons.forEach(function(radio) {
    radio.addEventListener('click', function() {
        var articleUni = document.getElementById("primer");
       

        if (radio.id === 'izquierda') {
           articleUni.style.textAlign='left';
        } else if (radio.id === 'centrado') {
          articleUni.style.textAlign='center';
        } else if (radio.id === 'derecha') {
            articleUni.style.textAlign='right';
        }
       
    });
});




