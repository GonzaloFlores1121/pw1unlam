

document.getElementById("suni").addEventListener("change", function() {
    var select = document.getElementById("suni");
    var nombreUniversidad = document.getElementById("nombreUniversidad");
    nombreUniversidad.innerText = select.options[select.selectedIndex].text;
});
var color=document.getElementById('color');
document.getElementById('color').addEventListener('change',
function(){
    var select = document.getElementById("color");
            var articleUni = document.querySelector('.cont');
            articleUni.style.backgroundColor = select.value;
})

var radioButtons = document.querySelectorAll('input[type="radio"]');
radioButtons.forEach(function(radio) {
    radio.addEventListener('click', function() {
        var articleUni = document.getElementById("nombreUniversidad");
        var colorTexto = 'black'; // Por defecto

        if (radio.id === 'blanco') {
            colorTexto = 'white';
        } else if (radio.id === 'gris') {
            colorTexto = 'gray';
        } else if (radio.id === 'amarillo') {
            colorTexto = 'yellow';
        }
        articleUni.style.color = colorTexto;
    });
});
