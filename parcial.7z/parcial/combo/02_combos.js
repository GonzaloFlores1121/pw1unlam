let colores=["azul","verde","amarillo"];
let paises=["Argentina","Brazil","Uruguay"];
let universidades=["UBA", "UNLAM", "UNSAM"];

let inicial=document.querySelector("#inicial");
let secundario=document.querySelector("#secundario");

inicial.addEventListener("change",()=>{
    secundario.innerHTML="";
    switch(inicial.value){
        case "1":
            for(let i = 0; i < colores.length; i++) {
                // Crear un nodo de tipo elemento option
                let option = document.createElement("option");
                
                // Agregarle un value al option
                option.value = colores[i];
                
                // Crear un nodo de tipo texto
                let texto = document.createTextNode(colores[i]);
                
                // Agregarle el texto al option
                option.appendChild(texto);
                
                // Agregar el option al select secundario
                secundario.appendChild(option);
            }
            break;

        case "2":
            for(let i = 0; i < paises.length; i++) {
                let option = document.createElement("option");
                option.value = paises[i];
                let texto = document.createTextNode(paises[i]);
                option.appendChild(texto);
                secundario.appendChild(option);
            }
            break;

        case "3":
            for(let i = 0; i < universidades.length; i++) {
                let option = document.createElement("option");
                option.value = universidades[i];
                let texto = document.createTextNode(universidades[i]);
                option.appendChild(texto);
                secundario.appendChild(option);
            }
            break;

        default:
            break;
    }
});
