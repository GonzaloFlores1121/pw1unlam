document.getElementById('agregar').addEventListener('click', function () {
    // Obtén el valor del input
    var nuevoItem = document.getElementById('item').value;

    // Verifica si el input no está vacío
    if (nuevoItem.trim() !== '') {
        // Crea un nuevo elemento li
        var nuevoElemento = document.createElement('li');

        // Asigna el texto del nuevo elemento
        nuevoElemento.textContent = nuevoItem;

        // Agrega el nuevo elemento a la lista
        document.getElementById('lenguajes').appendChild(nuevoElemento);

        // Limpia el valor del input
        document.getElementById('item').value = '';
    }
});
