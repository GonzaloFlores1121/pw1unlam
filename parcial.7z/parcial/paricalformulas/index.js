document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('boton').addEventListener('click', function (event) {
        event.preventDefault();

        // Obtén los valores de los campos
        var nombre = document.getElementById('nombre').value;
        var dni = document.getElementById('dni').value;
        var dniRepetido = document.getElementById('dniRepetido').value;
        var curso = document.getElementById('curso').value;
        var email = document.getElementById('email').value;

        // Validaciones
        var mensajeError = '';
        
        if (!nombre || !dni || !dniRepetido || !curso || !email) {
            mensajeError += 'Todos los campos son obligatorios. ';
        }

        if (nombre.length < 5 || nombre.length > 30) {
            mensajeError += 'El campo nombre y apellido debe tener entre 5 y 30 caracteres. ';
        }

        var regexEmail = /^[0-9a-zA-Z._.-]+@[0-9a-zA-Z._.-]+\.[0-9a-zA-Z]+$/;
        if (!regexEmail.test(email)) {
            mensajeError += 'El formato del email no es válido. ';
        }

        var regexDNI = /^[0-9]{8}$/;
        if (!regexDNI.test(dni)) {
            mensajeError += 'El DNI debe tener 8 caracteres numéricos. ';
        }

        if (dni !== dniRepetido) {
            mensajeError += 'El campo DNI y Repetir DNI deben ser iguales. ';
        }

        // Muestra los mensajes de error
        var mensajeDiv = document.getElementById('mensaje');
        mensajeDiv.innerHTML = mensajeError;
        mensajeDiv.style.color = 'red';

        // Si no hay mensajes de error, puedes enviar el formulario o realizar otras acciones
        if (!mensajeError) {
            // Aquí podrías enviar el formulario o realizar otras acciones
            mensajeDiv.innerHTML = 'Formulario enviado correctamente.';
            mensajeDiv.style.color = 'green';
        }
    });
});
